
import serial
import numpy as np
import matplotlib.pyplot as plt
import scipy.fft as fft


def serialPlot():
    rxflag = b'\x11'
    port = 'COM7'
    baudrate = 115200
    fs = 1000
    n_point = 1024

    ser = serial.Serial(port, baudrate)

    voltage = np.zeros(n_point)
    i = 0
    try:
        while True:
            # print('waiting!!', end = '\r')
            # print(ser.read(1))

            if  rxflag == ser.read(1):
                data = ser.read(4)
                data_str = data[0] << 24 | data[1] << 16 | data[2] << 8 | data[3]

                if data_str > 2**31:
                    data_str = 2**32 - data_str
                    data_str = -data_str
                print('data:', data_str, end= '\r')
                voltage[i] = data_str * 2.5  / (2**31)
                i = i + 1

                if i == n_point-1:

                    v = fft.fft(voltage)
                    v = 20*np.log10(abs(v))
                    f = fft.fftfreq(n_point, 1/fs)
                    
                    plt.figure(1)
                    plt.subplot(211)
                    plt.plot(range(n_point), voltage)
                    plt.xlabel('t')
                    plt.ylabel('v')
                    plt.xlim([0, 1000])

                    plt.subplot(212)
                    plt.plot(f, v)
                    plt.xlabel('f')
                    plt.ylabel('y')
                    
                    plt.tight_layout()
                    plt.show()
                    break
                
            else:
                print('waiting!!', end = '\r')
                
    except KeyboardInterrupt:
        ser.close()
        print("serial closed!\n")

def serialRead():
    rxflag = b'\x11'
    port = 'COM7'
    baudrate = 115200

    ser = serial.Serial(port, baudrate)

    try:
        while True:
            # print('waiting!!', end = '\r')
            # print(ser.read(1))
            if  rxflag == ser.read(1):
                data = ser.read(4)
                data_str = data[0] << 24 | data[1] << 16 | data[2] << 8 | data[3]

                if data_str > 2**31:
                    data_str = 2**32 - data_str
                    data_str = -data_str
                voltage = data_str * 2.5  / (2**31)
                print(f'data:{data_str}', end= '\r')
                # print('\n')
                print(f'voltage:{voltage} v', end= '\r')
            else:
                print('waiting!!', end = '\r')
                




    except KeyboardInterrupt:
        ser.close()
        print("serial closed!\n")
if __name__ == '__main__':
    # print('data:', 2**3)
    # print(b'0x11')
    # serialRead()
    serialPlot()