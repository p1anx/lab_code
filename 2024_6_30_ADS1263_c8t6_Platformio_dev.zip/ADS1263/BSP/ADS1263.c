#include "ADS1263.h"
#include <stdio.h>


void ADS1263_wreg(uint8_t reg_address, uint8_t n_data)
{
    uint8_t data[2];
    data[0] = reg_address | 0x40;
    data[1] = n_data;
    ADS_SPI_tx(data, 2);
}

void ADS1263_rreg(uint8_t reg_address, uint8_t n_data)
{
    uint8_t data[2];
    data[0] = reg_address | 0x20;
    data[1] = n_data;
    ADS_SPI_tx(data, 2);
}

void ADS1263_ReadID(void){ //ID = 0010 0011 (ascii: #, 0x23)

    uint8_t recvData;
    ADS1263_RESET_LOW();
    HAL_Delay(1);
    ADS1263_RESET_HIGH();
    HAL_Delay(1);
    ADS1263_CS_LOW();
    HAL_Delay(1);
    ADS1263_rreg(0x00, 1);
    ADS_SPI_rx(&recvData, 1);
    ADS1263_CS_HIGH();

    HAL_UART_Transmit(&huart1, &recvData, 1, 1000);

}

void ADS1263_WriteReg(uint8_t reg_address, uint8_t *reg_data){
    ADS1263_CS_LOW();
    ADS1263_wreg(reg_address, 1);
    ADS_SPI_tx(reg_data, 1);
    ADS1263_CS_HIGH();
}

void ADS1263_ReadReg(uint8_t reg_address, uint8_t *reg_data){
    ADS1263_CS_LOW();
    ADS1263_rreg(reg_address, 1);
    ADS_SPI_rx(reg_data, 1);
    ADS1263_CS_HIGH();
}

void ADS1263_ReadRegN(uint8_t reg_address, uint8_t *reg_data, uint8_t n_data){
    ADS1263_CS_LOW();
    ADS1263_rreg(reg_address, n_data);
    ADS_SPI_rx(reg_data, n_data);
    ADS1263_CS_HIGH();
}

void ADS1263_Init(void){
    
    uint8_t *Mode0_Setting = ADS1263_CONTINUOUS_CONVERSION;
    uint8_t *Mode1_Setting = ADS1263_SINC1_MODE;
    uint8_t *Mode2_Setting = ADS1263_GAIN_1 | ADS1263_DR_20;
    uint8_t *INPMUX_Setting = ADS1263_MUXP_AIN0 | ADS1263_MUXN_AINCOM;

    ADS1263_RESET_LOW();
    HAL_Delay(1);
    ADS1263_RESET_HIGH();
    ADS1263_WriteReg(ADS1263_Mode_0, Mode0_Setting);
    ADS1263_WriteReg(ADS1263_Mode_1, Mode1_Setting);
    ADS1263_WriteReg(ADS1263_Mode_2, Mode2_Setting);
    ADS1263_WriteReg(ADS1263_INPMUX, INPMUX_Setting);
    
    ADS1263_START();

}

void ADS1263_ReadData(void){
    // uint8_t data[3];
    char data[20];
    char data1[20];
    double voltage;

    ADS1263_CS_LOW();
    // while(1 == ADS1263_DRDY()); //wait for DRDY to go low
    uint8_t SPI_Transmit_Data[2];
    uint8_t SPI_Receive_Data[2];
    SPI_Transmit_Data[0]=ADS1263_CMD_RDATA_ADC1;//发送ADC1读取转换数据命令
    SPI_Transmit_Data[1]=0x00;//垫零字节
    HAL_SPI_TransmitReceive(&hspi1,SPI_Transmit_Data,SPI_Receive_Data,2,HAL_MAX_DELAY);//读取状态字节
    if((SPI_Receive_Data[1]&0x40)>>6==1)//检查状态字节的bit6是否为1（为1代表接下来的ADC1数据是最新的，否则是旧的）
    {
        uint8_t SPI_Transmit_Data[6];
        uint8_t SPI_Receive_Data[6];
        SPI_Transmit_Data[0]=ADS1263_CMD_RDATA_ADC1;//发送ADC1读取转换数据命令
        SPI_Transmit_Data[1]=0x00;//垫零字节
        HAL_SPI_TransmitReceive(&hspi1,SPI_Transmit_Data,SPI_Receive_Data,6,HAL_MAX_DELAY);//直接读取6个字节
        uint32_t Conveision_Data=(SPI_Receive_Data[2]<<24)|
        (SPI_Receive_Data[3]<<16)|
        (SPI_Receive_Data[4]<<8)|
        (SPI_Receive_Data[5]<<0);//读取到的6字节数据的低4位拼凑成转换数据
        // HAL_UART_Transmit(&huart1,(uint8_t*)&Conveision_Data,4,HAL_MAX_DELAY);//发送转换数据

        voltage = (double)Conveision_Data * 2.5 / 0x7fffffff;
        sprintf(data, "data:%d\n", Conveision_Data);
        sprintf(data1, "data1:%lf\n",voltage);
        HAL_UART_Transmit(&huart1, (uint8_t *)data, 20, 1000);
        HAL_UART_Transmit(&huart1, (uint8_t *)data1, 20, 1000);
        
    }
    ADS1263_CS_HIGH();

}

void ADS1263_Print(void){
    ADS1263_Init();
    while(1){
        ADS1263_ReadData();
        HAL_Delay(1000);
    }
}











