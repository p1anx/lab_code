#ifndef  __UART_PRINTF_H
#define  __UART_PRINTF_H

#include "usart.h"
#include <stdio.h>


#endif // ! __UART_PRINTF_H
